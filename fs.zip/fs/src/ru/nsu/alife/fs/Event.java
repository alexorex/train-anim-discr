package ru.nsu.alife.fs;

/**
 * Class describes event structure with:
 * start state before performing action,
 * action that performed,
 * results that could be obtained by performing action
 * and number of event occurrence
 */
class Event {
    private static final String TAG = Event.class.getName();

    /**
     * Start state before performing action
     */
    private PredicateSet state;

    /**
     * Action that performed
     */
    private IAction action;

    /**
     * Set of results that could be obtained by performing action
     */
    private EventResultSet results = new EventResultSet();

    /**
     * Number of event occurrence
     */
    private long occurrence;

    /**
     * Constructor. Creates instance with adjusted
     * start state, performed action and result state.
     * Occurrence will be set to 1;
     *
     * @param startState start state before performing action
     * @param action     action to perform
     * @param result     result state after action performing
     * @throws ru.nsu.alife.fs.InvalidArgumentException
     *
     */
    public Event(PredicateSet startState, IAction action, PredicateSet result) throws InvalidArgumentException {
        if (startState == null)
            throw new InvalidArgumentException(TAG, "Event", "startState", "null");
        if (action == null)
            throw new InvalidArgumentException(TAG, "Event", "action", "null");
        if (result == null)
            throw new InvalidArgumentException(TAG, "Event", "result", "null");

        this.state = startState;
        this.action = action;
        this.occurrence = 1L;
        this.results.put(result);
    }

    /**
     * Add new result state that was obtained after action performing
     *
     * @param result new result
     * @throws ru.nsu.alife.fs.InvalidArgumentException
     *
     */
    public void addResult(PredicateSet result) throws InvalidArgumentException {
        if (result == null)
            throw new InvalidArgumentException(TAG, "addResult", "result", "null");

        this.results.put(result);
        this.occurrence++;
    }

    /**
     * Check if current instance has the same to inputs start state and performed action
     *
     * @param startState input start state
     * @param action     input action
     * @return true if it has
     *         false if not
     * @throws ru.nsu.alife.fs.InvalidArgumentException
     *
     */
    public boolean hasStartStateAndAction(PredicateSet startState, IAction action) throws InvalidArgumentException {
        if (startState == null)
            throw new InvalidArgumentException(TAG, "hasStartStateAndAction", "startState", "null");
        if (action == null)
            throw new InvalidArgumentException(TAG, "hasStartStateAndAction", "action", "null");

        return this.action == action && this.state.contains(startState);
    }

    /**
     * Check if current instance has the same to input's start state
     *
     * @param startState input start state
     * @return true if it has
     *         false if not
     * @throws ru.nsu.alife.fs.InvalidArgumentException
     *
     */
    public boolean hasStartState(PredicateSet startState) {
        if (startState == null)
            throw new InvalidArgumentException(TAG, "hasStartState", "startState", "null");

        return this.state.contains(startState);
    }

    /**
     * Check if current instance contains input result in the set
     *
     * @param result result to check
     * @return true if instance contains input result,
     *         false if not
     * @throws ru.nsu.alife.fs.InvalidArgumentException
     *
     */
    public boolean hasResult(PredicateSet result) throws InvalidArgumentException {
        if (result == null)
            throw new InvalidArgumentException(TAG, "hasResultPattern", "result", "null");

        return this.results.contains(result);
    }

    /**
     * Get statistics of event with current instance's
     * start state and performed action and input result
     *
     * @param result result to choose and calculate statistics
     * @return calculates statistics for requested event
     * @throws ru.nsu.alife.fs.InvalidArgumentException
     *
     */
    public Statistics getStatisticsWithResult(PredicateSet result) throws InvalidArgumentException {
        if (result == null)
            throw new InvalidArgumentException(TAG, "getStatisticsWithResult", "result", "null");

        long occurrenceTotal = this.occurrence;
        long occurrencePositive = this.results.contains(result) ? this.results.getOccurrence(result) : 0;

        return new Statistics(occurrenceTotal, occurrencePositive);
    }

    /**
     * Getter for start state.
     *
     * @return copy of start state (because is should be immutable)
     */
    public PredicateSet getStartState() {
        return this.state.copy();
    }

    /**
     * Getter for performed action
     *
     * @return reference of performed action (action structure has just a behavior)
     */
    public IAction getPerformedAction() {
        return action;
    }

}
