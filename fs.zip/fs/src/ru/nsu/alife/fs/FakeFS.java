package ru.nsu.alife.fs;

/**
 * Test functional system, that perform
 * just random actions
 */
public class FakeFS implements IFS {
    private PredicateSet goal;

    public FakeFS(PredicateSet goal) {
        this.goal = goal;
    }

    public boolean reachGoal(IAcceptor acceptor) {
        acceptor.performRandomAction();

        return acceptor.getCurrentSituation().contains(goal);
    }
}
