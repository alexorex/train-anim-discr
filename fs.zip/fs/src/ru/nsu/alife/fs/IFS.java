package ru.nsu.alife.fs;

/**
 * Interface for FS
 * Used to fast switch between Fake and Real FS'
 */
public interface IFS {

    /**
     * Method should provide goal reaching mechanism
     *
     * @param acceptor acceptor to get data from upper system
     * @return true if goal reached
     *         false if not
     */
    public boolean reachGoal(IAcceptor acceptor);
}
