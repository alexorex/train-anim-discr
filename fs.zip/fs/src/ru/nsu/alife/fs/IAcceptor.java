package ru.nsu.alife.fs;

/**
 * Callback interface for functional systems.
 * Provides getters of necessary data:
 * - current situation (as PredicateSet)
 * - proactivity level (as double)
 * - random action (as implementation of IAction)
 */
public abstract class IAcceptor {
    private static final String TAG = IAcceptor.class.getName();
    /**
     * Method should return an random action,
     * that actually could be performed at current moment.
     *
     * @return action, that could be performed
     */
    public abstract IAction getRandomAction();

    /**
     * Method should return description of
     * current situation in predicates terms.
     * Predicates should have fixed places in set
     *
     * @return predicates list that describes situation
     */
    public abstract PredicateSet getCurrentSituation();

    /**
     * Method should return current "proactivity level"
     * of external (to fs) system
     *
     * @return "proactivity level" as double from 0 to 1
     */
    public abstract double getProactivity();

    /**
     * History instance bounded to current acceptor instance
     */
    private History history;

    /**
     * Get history instance which is bounded to current acceptor instance
     *
     * @return history instance
     */
     History getHistoryInstance(){
        if (history == null)
            history = History.getNewInstance();

        return history;
    }

    /**
     * Perform action and write event to history
     *
     * @param action to perform
     */
    void performAction(IAction action){

        PredicateSet eventStartState = this.getCurrentSituation();
        boolean performed = action.doAction();
        PredicateSet eventResult = this.getCurrentSituation();

        if (performed)
            this.getHistoryInstance().addEvent(eventStartState, action, eventResult);
    }

    /**
     * Perform random action and write event to history
     *
     * @return performed action
     */
    IAction performRandomAction(){
        IAction eventAction = this.getRandomAction();

        PredicateSet eventStartState = this.getCurrentSituation();
        boolean performed = eventAction.doAction();
        PredicateSet eventResult = this.getCurrentSituation();

        if (performed)
            this.getHistoryInstance().addEvent(eventStartState, eventAction, eventResult);

        return eventAction;
    }
}