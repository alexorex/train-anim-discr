package ru.nsu.alife.fs;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

/**
 * Class describes event structure with
 * set of Events and updatable statistics.
 */
class History {
    private static final String TAG = History.class.getName();

    /**
     * Constructor. Private - to prevent uncontrolled instance generation
     */
    private History() {
        this.events = Collections.synchronizedSet(new HashSet<Event>());
    }

    /**
     * Retrieve operating instance of this class
     *
     * @return instance
     */
    public static History getNewInstance() {
        return new History();
    }

    /**
     * Set of events that occurred during application working
     */
    private Set<Event> events;

    /**
     * Add a new event into history's set of events
     * or add new result into existed event.
     *
     * @param startState start state of input event
     * @param action     action performed during input event
     * @param result     result state that was obtained after action performing
     * @throws ru.nsu.alife.fs.InvalidArgumentException
     *
     */
    public void addEvent(PredicateSet startState, IAction action, PredicateSet result) throws InvalidArgumentException {
        if (startState == null)
            throw new InvalidArgumentException(TAG, "addEvent", "startState", "null");
        if (action == null)
            throw new InvalidArgumentException(TAG, "addEvent", "action", "null");
        if (result == null)
            throw new InvalidArgumentException(TAG, "addEvent", "result", "null");

        for (Event event : this.events) {
            if (event.hasStartStateAndAction(startState, action)) {
                event.addResult(result.copy());
                return;
            }
        }

        this.events.add(new Event(startState.copy(), action, result.copy()));
    }

    /**
     * Get set of events by input result.
     *
     * @param result result pattern
     * @return set of suitable events
     * @throws ru.nsu.alife.fs.InvalidArgumentException
     *
     */
    public Set<Event> getEventsWithResult(PredicateSet result) throws InvalidArgumentException {
        if (result == null)
            throw new InvalidArgumentException(TAG, "getEventsWithResult", "result", "null");

        Set<Event> resultEvents = new HashSet<Event>();

        for (Event event : this.events) {
            if (event.hasResult(result)) {
                resultEvents.add(event);
            }
        }

        return resultEvents;
    }

    /**
     * Get total statistics of events with input characteristics
     *
     * @param startState start state of requested event
     * @param action     action performed during requested event
     * @param result     result state that was obtained after action performing
     * @return calculated total statistics of all suitable events
     * @throws ru.nsu.alife.fs.InvalidArgumentException
     *
     */
    public Statistics getStatistics(PredicateSet startState, IAction action, PredicateSet result) throws InvalidArgumentException {
        if (startState == null)
            throw new InvalidArgumentException(TAG, "getStatistics", "startState", "null");
        if (action == null)
            throw new InvalidArgumentException(TAG, "getStatistics", "action", "null");
        if (result == null)
            throw new InvalidArgumentException(TAG, "getStatistics", "result", "null");

        Statistics statistics = new Statistics();
        for (Event event : events) {
            if (event.hasStartStateAndAction(startState, action)) {
                statistics.join(event.getStatisticsWithResult(result));
            }
        }

        return statistics;
    }
}
