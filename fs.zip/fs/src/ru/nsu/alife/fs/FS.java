package ru.nsu.alife.fs;

import java.util.*;

/**
 * Primary class that provides
 * mechanism of adjusted goal reaching
 */
public class FS implements IFS {
    private static final String TAG = FS.class.getName();

    /**
     * Lowest limit of rule probability in the set
     * Rule with lower probability will be removed
     */
    private static double MIN_PROBABILITY = 0.75;

    /**
     * Primary goal of FS
     */
    private final PredicateSet goal;

    /**
     * Map that represents set of rules usable
     * in different situations mapped to
     * set of FS, which represents sub-goals
     */
    private final HashMap<Rule, FS> rules;

    /**
     * Depth of current FS in the hierarchy. Descending
     */
    private int depth;

    /**
     * Constructor. Creates FS with new goal
     *
     * @param goal  primary FS goal
     * @param depth depth in the hierarchy
     */
    public FS(PredicateSet goal, int depth) {
        this.goal = goal;
        this.depth = depth;

        this.rules = new HashMap<Rule, FS>();
    }

    /**
     * Find the most appropriate rule in the rules set
     *
     * @param situation input situation criteria
     * @return founded rule
     */
    private Rule findRule(PredicateSet situation) {
        double maxProbability = 0;
        Set<Rule> rulesToRemove = new HashSet<Rule>();
        Rule bestRule = null;
        for (Rule rule : this.rules.keySet()) {
            if (rule.matches(situation)) {
                double probability = rule.getProbability();
                if (probability > MIN_PROBABILITY) {
                    if (probability > maxProbability) {
                        bestRule = rule;
                        maxProbability = probability;
                    }
                } else {
                    rulesToRemove.add(rule);
                }
            }
        }

        for (Rule rule : rulesToRemove)
            this.rules.remove(rule);

        return bestRule;
    }

    /**
     * Find the most appropriate sub-goal to achieve
     *
     * @param situation input situation criteria
     * @return founded FS
     */
    private FS findSubFs(PredicateSet situation) {
        double maxProbability = 0;
        FS bestFs = null;
        for (FS fs : this.rules.values()) {
            if (fs == null) continue;

            double probability = fs.getProbability(situation);
            if (probability > MIN_PROBABILITY && probability > maxProbability) {
                bestFs = fs;
                maxProbability = probability;
            }
        }

        return bestFs;
    }

    /**
     * Predict goal reaching probability that
     * can be retrieved using this FS
     *
     * @param situation input situation
     * @return probability
     */
    private double getProbability(PredicateSet situation) {
        Rule rule = findRule(situation);
        FS subFs = findSubFs(situation);

        double ruleProbability = rule != null ? rule.getProbability() : 0;
        double subFsProbability;

        if (subFs == null)
            subFsProbability = 0;
        else {
            Rule tRule = null;
            for (Rule item : this.rules.keySet()) {
                if (rules.get(item) == subFs) {
                    tRule = item;
                    break;
                }
            }

            subFsProbability = subFs.getProbability(situation) * tRule.getProbability();
        }

        return Math.max(ruleProbability, subFsProbability);
    }

    /**
     * Rules and sub-goals generalization mechanism
     * If one rule partially contains other - deactivate
     * targeted predicates.
     *
     * @param acceptor callback interface to retrieve data
     */
    private void generalizeRules(IAcceptor acceptor) {
        History history = acceptor.getHistoryInstance();
        Set<Rule> rulesToRemove = new HashSet<Rule>();
        HashMap<Rule, FS> rulesToAdd = new HashMap<Rule, FS>();

        do {
            rulesToAdd.clear();
            rulesToRemove.clear();
            LinkedList<Rule> ruleList = new LinkedList<Rule>(this.rules.keySet());
            for (Iterator<Rule> iteratorA = ruleList.iterator(); iteratorA.hasNext();) {
                Rule ruleA = iteratorA.next();
                for (Iterator<Rule> iteratorB = ruleList.descendingIterator(); iteratorB.hasNext();) {
                    Rule ruleB = iteratorB.next();

                    if (ruleA == ruleB)
                        break;

                    if (!ruleA.hasSameAction(ruleB)) {
                        continue;
                    }

                    PredicateSet newSituation = ruleA.getGeneralizedPredicates(ruleB);
                    if (!newSituation.hasActivePredicates())
                        continue;

                    if (!ruleA.partiallyContains(ruleB) && !ruleB.partiallyContains(ruleA))
                        continue;

                    IAction action = ruleA.getAction();

                    Statistics statistics = history.getStatistics(
                            newSituation, action, this.goal);
                    double statCalculated = statistics.calcProbability();
                    if (statCalculated >= ruleA.getProbability()
                            && statCalculated >= ruleB.getProbability()) {
                        FS newFS;
                        if (rules.get(ruleA) == null && rules.get(ruleB) == null)
                            newFS = generateSubFS(acceptor, newSituation);
                        else
                            newFS = mergeFs(acceptor, rules.get(ruleA), rules.get(ruleB), newSituation);
                        Rule newRule = new Rule(newSituation, action, statistics);

                        rulesToRemove.add(ruleA);
                        rulesToRemove.add(ruleB);

                        for (Rule rule : this.rules.keySet()) {
                            if (rule.getAction() == action && rule.matches(newSituation)) {
                                rulesToRemove.add(rule);
                                FS fs = this.rules.get(rule);
                                if (fs != null)
                                    newFS = mergeFs(acceptor, newFS, fs, newSituation);
                            }
                        }
                        rulesToAdd.put(newRule, newFS);
                    }
                }
            }

            for (Rule rule : rulesToRemove)
                this.rules.remove(rule);

            this.rules.putAll(rulesToAdd);

        } while (rulesToAdd.size() > 0 || rulesToRemove.size() > 0);

        rulesToRemove.clear();
        for (Rule entry : rules.keySet())
            if (entry.getProbability() < MIN_PROBABILITY)
                rulesToRemove.add(entry);

        for (Rule rule : rulesToRemove)
            this.rules.remove(rule);
    }

    /**
     * Retrieve rule from map by input FS
     *
     * @param fs input fs
     * @return rule that mapped to input fs
     */
    private Rule getRuleForFs(FS fs) {
        Rule result = null;
        for (Rule item : this.rules.keySet()) {
            if (rules.get(item) == fs) {
                result = item;
                break;
            }
        }

        return result;
    }

    /**
     * <p> Main method. Tries to reach FS' goal, performing steps: </p>
     * <p> 1. get current situation from acceptor </p>
     * <p> 2. find a rule appropriate in current situation </p>
     * <p> find a sub-goal to reach appropriate in current situation </p>
     * <p> + if no rule and subFS found -> perform random action </p>
     * <p> + if rule execution has higher probability to reach goal
     * than subFS reaching -> execute found rule </p>
     * <p> + if rule execution has lower probability to reach goal
     * than subFS reaching -> try to reach sub-goal </p>
     * <p> 3. get changed situation from acceptor </p>
     * <p> 4. compare goal and changed situations </p>
     * <p> 5. if matches -> increase probability of a rule </p>
     * <p> 6. if not matches -> decrease probability of a rule </p>
     *
     * @param acceptor callback interface to retrieve data
     * @return true if goal reached, false if not
     * @throws ru.nsu.alife.fs.InvalidArgumentException
     *
     */
    @Override
    public boolean reachGoal(IAcceptor acceptor)
            throws InvalidArgumentException {
        if (acceptor == null)
            throw new InvalidArgumentException(TAG, "reachGoal", "acceptor", "null");

//        MIN_PROBABILITY = 1.0 - acceptor.getProactivity();

        PredicateSet currentSituation;
        IAction actionPerformed = null;
        PredicateSet changedSituation;

        currentSituation = acceptor.getCurrentSituation();

        if (currentSituation.contains(this.goal))
            return true;

        Rule rule = this.findRule(currentSituation);
        FS subFs = this.findSubFs(currentSituation);
        double ruleProbability = rule != null ? rule.getProbability() : 0;
        double subFsProbability;

        if (subFs == null)
            subFsProbability = 0;
        else {
            Rule tRule = getRuleForFs(subFs);

            subFsProbability = subFs.getProbability(currentSituation) * tRule.getProbability();
        }

        if (ruleProbability < subFsProbability) {
            rule = getRuleForFs(subFs);

            if (subFs.reachGoal(acceptor)) {
                rule.execute(acceptor);
            } else {
                return false;
            }
        } else {
            if (rule == null) {
                actionPerformed = acceptor.performRandomAction();
                changedSituation = acceptor.getCurrentSituation();
                this.updateRules(acceptor, currentSituation, actionPerformed, changedSituation);
            } else {
                rule.execute(acceptor);
            }
        }

        changedSituation = acceptor.getCurrentSituation();
        boolean goalReached = changedSituation.contains(this.goal);

        if (goalReached) {
            if (rule == null) {
                rule = new Rule(currentSituation, actionPerformed, new Statistics());
            }

            if (!rules.containsKey(rule))
                rules.put(rule, generateSubFS(acceptor, currentSituation));

            rule.encourage();

            this.generalizeRules(acceptor);
        } else {
            if (rule != null)
                rule.punish();
            if (subFsProbability < MIN_PROBABILITY)
                rules.remove(getRuleForFs(subFs));
        }

        return goalReached;
    }

    /**
     * Update set of rules of current FS and all it's subFS
     * if endSituation contains current FS' goal
     *
     * @param acceptor       callback interface to retrieve data
     * @param startSituation start situation to generate rule
     * @param action         action to generate rule
     * @param endSituation   situation to check
     */
    private void updateRules(IAcceptor acceptor, PredicateSet startSituation, IAction action, PredicateSet endSituation) {
        if (endSituation.contains(this.goal)) {
            Statistics statistics = acceptor.getHistoryInstance().getStatistics(startSituation, action, endSituation);
            if (statistics.calcProbability() > MIN_PROBABILITY) {
                Rule rule = new Rule(startSituation, action, statistics);
                rules.put(rule, null);

                this.generalizeRules(acceptor);
            }
        }

        for (FS fs : rules.values()) {
            if (fs != null)
                fs.updateRules(acceptor, startSituation, action, endSituation);
        }
    }

    /**
     * Merge two FSs to one by generalization FS' goals
     * and merging rules and sub-goal sets
     *
     * @param acceptor callback interface to retrieve data
     * @param fsA      first FS
     * @param fsB      second FS
     * @param goal     already generalized goal
     * @return merged FS
     */
    private static FS mergeFs(IAcceptor acceptor, FS fsA, FS fsB, PredicateSet goal) {
        FS resultFS = null;
        if (fsA != null && fsB != null) {
            resultFS = new FS(goal, fsA.depth);
            resultFS.rules.putAll(fsA.rules);
            resultFS.rules.putAll(fsB.rules);
//            resultFS.generalizeRules(acceptor);
        } else if (fsA != null) {
            resultFS = new FS(goal, fsA.depth);

            resultFS.rules.putAll(fsA.rules);
        } else if (fsB != null) {
            resultFS = new FS(goal, fsB.depth);

            resultFS.rules.putAll(fsB.rules);
        }

        return resultFS;
    }

    /**
     * Sub-goals generation mechanism.
     *
     * @param acceptor callback interface to retrieve data
     * @throws ru.nsu.alife.fs.InvalidArgumentException
     *
     */
    private FS generateSubFS(IAcceptor acceptor, PredicateSet goal) {
        History history = acceptor.getHistoryInstance();
        FS resultFs;
        if (depth > 0)
            resultFs = new FS(goal, depth - 1);
        else
            return null;

        Set<Event> events = history.getEventsWithResult(goal);
        Set<Rule> rules = generateRules(events, goal);

        for (Rule rule : rules)
            resultFs.rules.put(rule, null);

//        resultFs.generalizeRules(acceptor);

        return resultFs;
    }

    /**
     * Generate rules from input set of events by adjusted result
     *
     * @param events      input set of events
     * @param eventResult result criteria to rule generation
     * @return generated set of rules
     * @throws ru.nsu.alife.fs.InvalidArgumentException
     *
     */
    private static Set<Rule> generateRules(Set<Event> events, PredicateSet eventResult) {
        if (events == null)
            throw new InvalidArgumentException(TAG, "generateRules", "events",
                    "null");
        if (eventResult == null)
            throw new InvalidArgumentException(TAG, "generateRules",
                    "eventResult", "null");

        Set<Rule> resultRules = new HashSet<Rule>();
        for (Event event : events) {
            PredicateSet rulePredicates = event.getStartState();
            IAction ruleAction = event.getPerformedAction();
            Statistics statistics = event.getStatisticsWithResult(eventResult);

            if (statistics.calcProbability() > MIN_PROBABILITY)
                resultRules.add(new Rule(rulePredicates, ruleAction, statistics));
        }

        return resultRules;
    }
}
